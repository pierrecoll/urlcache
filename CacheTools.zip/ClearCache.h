#ifndef __ClearCache_H__
#define __ClearCache_H__

//////////////////////////////////////////////////////////////////////
// Classe : CacheEntry
// Resume : Clear Selected Cache Entry
//////////////////////////////////////////////////////////////////////

#include <WinInet.h>

class CClearCache
{
	public:

		CClearCache();
		~CClearCache();

	protected:

		void		DelCache();
		bool		DelCache(INTERNET_CACHE_ENTRY_INFO*);

	public:
		void		ClearTemporary();
		void		ClearHistory();
		void		ClearCookies();
		void		ClearSelectTemporary(LPTSTR);
		void		ClearAll();

};
#endif
