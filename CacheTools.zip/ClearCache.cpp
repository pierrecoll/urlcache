//////////////////////////////////////////////////////////////////////
// Classe : CacheEntry
// Resume : Clear Selected Cache Entry
////////////

#include "stdafx.h"
#include "ClearCache.h"
#include "CacheInfo.h"
#include "CacheEntry.h"

#include <shlguid.h>
#include <urlhist.h> 

//////////////////////////////////////////////////////////////////////
// Methode : CClearCache
// Resume : Constructeur
// In : None
// Out : None
//////////////////////////////////////////////////////////////////////
CClearCache::CClearCache()
{

}
//////////////////////////////////////////////////////////////////////
// Methode : ~CClearCache
// Resume : Destructor
// In : None
// Out : None
//////////////////////////////////////////////////////////////////////
CClearCache::~CClearCache()
{

}
//////////////////////////////////////////////////////////////////////
// Methode : ClearTemporary
// Resume : Clear Temporary Internet Files
// In : None
// Out : None
//////////////////////////////////////////////////////////////////////
void CClearCache::ClearTemporary()
{
	CCacheEntry CacheEntry;

	LPINTERNET_CACHE_ENTRY_INFO pInfo = CacheEntry.First();

	while(pInfo)
	{
		if(CacheEntry.IsTemporary(pInfo->CacheEntryType))
		{
			DelCache(pInfo);
		}
		pInfo = CacheEntry.Next();
	}
}
void CClearCache::ClearSelectTemporary(LPTSTR Extension)
{
	CCacheEntry CacheEntry;

	LPINTERNET_CACHE_ENTRY_INFO pInfo = CacheEntry.First();

	while(pInfo)
	{
		if(CacheEntry.IsTemporary(pInfo->CacheEntryType))
		{
			if ( _stricmp(pInfo->lpszFileExtension,Extension))
			DelCache(pInfo);
		}
		pInfo = CacheEntry.Next();
	}
}

//////////////////////////////////////////////////////////////////////
// Methode : ClearCookies
// Resume : Clear Cookies
// In : None
// Out : None
//////////////////////////////////////////////////////////////////////
void CClearCache::ClearCookies()
{
	CCacheEntry CacheEntry;
	LPINTERNET_CACHE_ENTRY_INFO pInfo = CacheEntry.FirstCookie();
	
	while(pInfo)
	{
		DelCache(pInfo);
		pInfo = CacheEntry.Next();
	}
}
//////////////////////////////////////////////////////////////////////
// Methode : ClearHistory
// Resume : Clear History
// In : None
// Out : None
//////////////////////////////////////////////////////////////////////
void CClearCache::ClearHistory()
{
	CCacheEntry CacheEntry;

	LPINTERNET_CACHE_ENTRY_INFO pInfo = CacheEntry.FirstHistory();

	RegDeleteKey(HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\Internet Explorer\\TypedURLs"));
	RegDeleteKey(HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU"));

	while(pInfo)
	{
		DelCache(pInfo);
		pInfo = CacheEntry.Next();
	}

	IUrlHistoryStg2* pHistory;  // We need this interface for clearing the history.
	HRESULT hr;
	DWORD cRef;
	CoInitialize(NULL);

	// Load the correct Class and request IUrlHistoryStg2
	hr = CoCreateInstance(	CLSID_CUrlHistory, 
							NULL, 
							CLSCTX_INPROC_SERVER,
							IID_IUrlHistoryStg2, 
							reinterpret_cast<void **>(&pHistory));

    if (SUCCEEDED(hr))
    {
		// Clear the IE History
		hr = pHistory->ClearHistory();
	}
	// Release our reference to the 
	cRef = pHistory->Release();
	CoUninitialize();
}
//////////////////////////////////////////////////////////////////////
// Methode : DelCache
// Resume : Delete Cache sepcified cache entry
// In : None
// Out : None
//////////////////////////////////////////////////////////////////////
bool CClearCache::DelCache(INTERNET_CACHE_ENTRY_INFO* pInfo)
{
	return (::DeleteUrlCacheEntry(pInfo->lpszSourceUrlName) ? true : false);
}

void CClearCache::ClearAll()
{
	CCacheEntry CacheEntry;

	LPINTERNET_CACHE_ENTRY_INFO pInfo = CacheEntry.First();

	while(pInfo)
	{

		DelCache(pInfo);

		pInfo = CacheEntry.Next();
	}

	_tprintf(_T("Cache Cleared\n"));
}