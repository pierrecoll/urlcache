#include "stdafx.h"
#include "CacheTools.h"
#include "ClearCache.h"
#include "DisplayCache.h"
#include <stdio.h>

//////////////////////////////////////////////////////////////////////
// Classe : Main
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
// Methode : DisplayHelp
// Resume : Display Help
// In : None
// Out : None
//////////////////////////////////////////////////////////////////////
void DisplayHelp()
{
	printf("\nCacheTools : Clear Cookies, History and Temporary Internet Files\n\n");
	printf("Options : \n\n");
	printf("  To clear cache entries use the options listed below\n\n");
	printf("    -c:h   Clear previous Day History But Not Today (By Design)\n");
	printf("    -c:c   Clear Cookies\n");
	printf("    -c:t   Clear Temporary Internet Files\n");
	printf("    -c:a   Clear all the cache entries\n\n");
	printf("  To display cache entries use the options listed below\n\n");
	printf("    -d:h   Display History\n");
	printf("    -d:c   Display Cookies\n");
	printf("    -d:t   Display Temporary Internet Files\n");
	printf("    -d:a   Display all the cache entries\n\n");
	printf("    To prevent displaying one or more cache entries info use the swithes below\n\n");
	printf("      -r:StructSize		for StructSize\n");
	printf("      -r:SourceUrlName		for SourceUrlName\n");
	printf("      -r:LocalFileName		for LocalFileName\n");
	printf("      -r:CacheEntryType		for CacheEntryType\n");
	printf("      -r:UseCount		for UseCount\n");
	printf("      -r:HitRate		for HitRate\n");
	printf("      -r:SizeLow		for SizeLow\n");
	printf("      -r:SizeHigh		for SizeHigh\n");
	printf("      -r:LastModifiedTime	for LastModifiedTime\n");
	printf("      -r:ExpireTime		for ExpireTime\n");
	printf("      -r:LastAccessTime		for LastAccessTime\n");
	printf("      -r:LastSyncTime		for LastSyncTime\n");
	printf("      -r:HeaderInfo		for HeaderInfo\n");
	printf("      -r:HeaderInfoSize		for HeaderInfoSize\n");
	printf("      -r:FileExtension		for FileExtension\n\n");
	printf("   For example : \n\n");
	printf("     CacheTools -r:StructSize -r:CacheEntryType will remove StructSize and CacheEntryType\n\n");
/* 
/* Not Yet Implemented Need Time :)
/* 
	printf("   To display particular cache entries with a certain string on it \n\n");
	printf("      -s:StructSize [string]		for StructSize\n");
	printf("      -s:SourceUrlName [string]		for SourceUrlName\n");
	printf("      -s:LocalFileName [string]		for LocalFileName\n");
	printf("      -s:CacheEntryType [string]	for CacheEntryType\n");
	printf("      -s:UseCount [string]		for UseCount\n");
	printf("      -s:HitRate [string]		for HitRate\n");
	printf("      -s:SizeLow [string]		for SizeLow\n");
	printf("      -s:SizeHigh [string]		for SizeHigh\n");
	printf("      -s:LastModifiedTime [string]	for LastModifiedTime\n");
	printf("      -s:ExpireTime [string]		for ExpireTime\n");
	printf("      -s:LastAccessTime [string]	for LastAccessTime\n");
	printf("      -s:LastSyncTime [string]		for LastSyncTime\n");
	printf("      -s:HeaderInfo [string]		for HeaderInfo\n");
	printf("      -s:HeaderInfoSize [string]	for HeaderInfoSize\n");
	printf("      -s:FileExtension [string]		for FileExtension\n\n");
	printf("   For example : \n\n");
	printf("     CacheTools -s:SourceUrlName sample only display the cache entry with the string sample in the cache entry SourceUrlName\n\n");
*/
}
//////////////////////////////////////////////////////////////////////
// Methode : LoopStringUpper
// Resume : Like strstr but non case sensitive 
//			Return a pointer to the first occurrence of a search string in a string.
// In : *arg1 = string 
//		*arg2 = search string
// Out : pointer to the first occurrence
// Extract from http://msdn2.microsoft.com/en-us/library/z9da80kz(VS.80).aspx
//////////////////////////////////////////////////////////////////////
char * LoopStringUpper(const char *arg1, const char *arg2)
{
	char buff1[MAX_PATH];
	char buff2[MAX_PATH];

	strcpy(buff1,arg1);
	strcpy(buff2,arg2);

	strupr(buff1);
	strupr(buff2);

	return strstr(buff1,buff2);

}
//////////////////////////////////////////////////////////////////////
// Methode : main
// Resume : Main Function
// In : None
// Out : None
//////////////////////////////////////////////////////////////////////
int main(int argc, char* argv[])
{
	int nRetCode = 0;
	int i,inf;
	char arg[MAX_PATH];
	CClearCache ClearCache;
	CDisplayCache DisplayCache;
	LPTSTR Ext;
	Ext = 0;

    inf = 0;

	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
		if (argc==1) DisplayHelp(); 

		for (i=1;i<argc;i++)
		{
			strcpy(arg,argv[i]);

			if (LoopStringUpper(arg,"-r") != 0)
			{
				DisplayCache.m_b_Remove = 1;

				if (LoopStringUpper(arg,":StructSize"))			DisplayCache.m_bDisp_dwStructSize		= 0;
				else if (LoopStringUpper(arg,":SourceUrlName"))	DisplayCache.m_bDisp_lpszSourceUrlName	= 0;
				else if (LoopStringUpper(arg,":LocalFileName"))	DisplayCache.m_bDisp_lpszLocalFileName	= 0;
				else if (LoopStringUpper(arg,":CacheEntryType"))	DisplayCache.m_bDisp_CacheEntryType		= 0;
				else if (LoopStringUpper(arg,":UseCount"))		DisplayCache.m_bDisp_dwUseCount			= 0;
				else if (LoopStringUpper(arg,":HitRate"))		DisplayCache.m_bDisp_dwHitRate			= 0;
				else if (LoopStringUpper(arg,":SizeLow"))		DisplayCache.m_bDisp_dwSizeLow			= 0;
				else if (LoopStringUpper(arg,":SizeHigh"))		DisplayCache.m_bDisp_dwSizeHigh			= 0;
				else if (LoopStringUpper(arg,":LastModifiedTime"))DisplayCache.m_bDisp_LastModifiedTime	= 0;
				else if (LoopStringUpper(arg,":ExpireTime"))		DisplayCache.m_bDisp_ExpireTime			= 0;
				else if (LoopStringUpper(arg,":LastAccessTime"))	DisplayCache.m_bDisp_LastAccessTime		= 0;	 
				else if (LoopStringUpper(arg,":LastSyncTime"))	DisplayCache.m_bDisp_LastSyncTime		= 0;
				else if (LoopStringUpper(arg,":HeaderInfo"))		DisplayCache.m_bDisp_lpHeaderInfo		= 0;
				else if (LoopStringUpper(arg,":HeaderInfoSize"))	DisplayCache.m_bDisp_dwHeaderInfoSize	= 0;
				else if (LoopStringUpper(arg,":FileExtension"))	DisplayCache.m_bDisp_lpszFileExtension	= 0;
				else printf("\nSyntax error please read help using -h \n\n");
			}
		
		}
		for (i=1;i<argc;i++)
		{
			strcpy(arg,argv[i]);
			strupr(arg);

			if (LoopStringUpper(arg,"-h") != NULL)
			{
				DisplayHelp();
			};
			if (LoopStringUpper(arg,"-d") != NULL)
			{
				if (LoopStringUpper(arg,":h") != NULL) DisplayCache.DisplayHistory();
				else if (LoopStringUpper(arg,":c") != 0) DisplayCache.DisplayCookies();
				else if (LoopStringUpper(arg,":t") != 0) DisplayCache.DisplayTemporary();
				else if (LoopStringUpper(arg,":a") != 0) DisplayCache.DisplayAll();
				else 	printf("\nSyntax error please read help using -h \n\n");
			}
			if (LoopStringUpper(arg,"-c") != 0)
			{
				if (LoopStringUpper(arg,":h") != 0) ClearCache.ClearHistory();
				else if (LoopStringUpper(arg,":c") != 0) ClearCache.ClearCookies();
				else if (LoopStringUpper(arg,":t") != 0) ClearCache.ClearTemporary();
				else if (LoopStringUpper(arg,":a") != 0) ClearCache.ClearAll();
				else 	printf("\nSyntax error please read help using -h \n\n");
			}
		}
	}
	return nRetCode;
}

